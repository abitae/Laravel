<!DOCTYPE html>
<html lang="en-US">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover" /> <title>Page not found &#8211; NSDBytes</title>
<meta name='robots' content='max-image-preview:large' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="NSDBytes &raquo; Feed" href="https://nsdbytes.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="NSDBytes &raquo; Comments Feed" href="https://nsdbytes.com/comments/feed/" />

<script src="//www.googletagmanager.com/gtag/js?id=UA-118589895-1" type="text/javascript" data-cfasync="false" async></script>
<script type="text/javascript" data-cfasync="false">
				var mi_version = '7.18.0';
				var mi_track_user = true;
				var mi_no_track_reason = '';
				
								var disableStr = 'ga-disable-UA-118589895-1';

				/* Function to detect opted out users */
				function __gtagTrackerIsOptedOut() {
					return document.cookie.indexOf( disableStr + '=true' ) > - 1;
				}

				/* Disable tracking if the opt-out cookie exists. */
				if ( __gtagTrackerIsOptedOut() ) {
					window[disableStr] = true;
				}

				/* Opt-out function */
				function __gtagTrackerOptout() {
					document.cookie = disableStr + '=true; expires=Thu, 31 Dec 2099 23:59:59 UTC; path=/';
					window[disableStr] = true;
				}

				if ( 'undefined' === typeof gaOptout ) {
					function gaOptout() {
						__gtagTrackerOptout();
					}
				}
								window.dataLayer = window.dataLayer || [];
				if ( mi_track_user ) {
					function __gtagTracker() {dataLayer.push( arguments );}
					__gtagTracker( 'js', new Date() );
					__gtagTracker( 'set', {
						'developer_id.dZGIzZG' : true,
						                    });
					__gtagTracker( 'config', 'UA-118589895-1', {
						forceSSL:true,link_attribution:true,page_path:'/404.html?page=' + document.location.pathname + document.location.search + '&from=' + document.referrer,					} );
										window.gtag = __gtagTracker;										(
						function () {
							/* https://developers.google.com/analytics/devguides/collection/analyticsjs/ */
							/* ga and __gaTracker compatibility shim. */
							var noopfn = function () {
								return null;
							};
							var newtracker = function () {
								return new Tracker();
							};
							var Tracker = function () {
								return null;
							};
							var p = Tracker.prototype;
							p.get = noopfn;
							p.set = noopfn;
							p.send = function (){
								var args = Array.prototype.slice.call(arguments);
								args.unshift( 'send' );
								__gaTracker.apply(null, args);
							};
							var __gaTracker = function () {
								var len = arguments.length;
								if ( len === 0 ) {
									return;
								}
								var f = arguments[len - 1];
								if ( typeof f !== 'object' || f === null || typeof f.hitCallback !== 'function' ) {
									if ( 'send' === arguments[0] ) {
										var hitConverted, hitObject = false, action;
										if ( 'event' === arguments[1] ) {
											if ( 'undefined' !== typeof arguments[3] ) {
												hitObject = {
													'eventAction': arguments[3],
													'eventCategory': arguments[2],
													'eventLabel': arguments[4],
													'value': arguments[5] ? arguments[5] : 1,
												}
											}
										}
										if ( 'pageview' === arguments[1] ) {
											if ( 'undefined' !== typeof arguments[2] ) {
												hitObject = {
													'eventAction': 'page_view',
													'page_path' : arguments[2],
												}
											}
										}
										if ( typeof arguments[2] === 'object' ) {
											hitObject = arguments[2];
										}
										if ( typeof arguments[5] === 'object' ) {
											Object.assign( hitObject, arguments[5] );
										}
										if ( 'undefined' !== typeof arguments[1].hitType ) {
											hitObject = arguments[1];
											if ( 'pageview' === hitObject.hitType ) {
												hitObject.eventAction = 'page_view';
											}
										}
										if ( hitObject ) {
											action = 'timing' === arguments[1].hitType ? 'timing_complete' : hitObject.eventAction;
											hitConverted = mapArgs( hitObject );
											__gtagTracker( 'event', action, hitConverted );
										}
									}
									return;
								}

								function mapArgs( args ) {
									var arg, hit = {};
									var gaMap = {
										'eventCategory': 'event_category',
										'eventAction': 'event_action',
										'eventLabel': 'event_label',
										'eventValue': 'event_value',
										'nonInteraction': 'non_interaction',
										'timingCategory': 'event_category',
										'timingVar': 'name',
										'timingValue': 'value',
										'timingLabel': 'event_label',
										'page' : 'page_path',
										'location' : 'page_location',
										'title' : 'page_title',
									};
									for ( arg in args ) {
										if ( args.hasOwnProperty(arg) && gaMap.hasOwnProperty(arg) ) {
											hit[gaMap[arg]] = args[arg];
										} else {
											hit[arg] = args[arg];
										}
									}
									return hit;
								}

								try {
									f.hitCallback();
								} catch ( ex ) {
								}
							};
							__gaTracker.create = newtracker;
							__gaTracker.getByName = newtracker;
							__gaTracker.getAll = function () {
								return [];
							};
							__gaTracker.remove = noopfn;
							__gaTracker.loaded = true;
							window['__gaTracker'] = __gaTracker;
						}
					)();
									} else {
										console.log( "" );
					( function () {
							function __gtagTracker() {
								return null;
							}
							window['__gtagTracker'] = __gtagTracker;
							window['gtag'] = __gtagTracker;
					} )();
									}
			</script>

<script type="e695cee98d767db72b8d8e31-text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/nsdbytes.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.8.1"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([10084,65039,8205,55357,56613],[10084,65039,8203,55357,56613])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
<style>
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://nsdbytes.com/wp-includes/css/dist/block-library/style.min.css?ver=5.8.1' media='all' />
<link rel='stylesheet' id='contact-form-7-css' href='https://nsdbytes.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.4.2' media='all' />
<link rel='stylesheet' id='twentytwenty-style-css' href='https://nsdbytes.com/wp-content/themes/twentytwenty/style.css?ver=1.8' media='all' />
<style id='twentytwenty-style-inline-css'>
.color-accent,.color-accent-hover:hover,.color-accent-hover:focus,:root .has-accent-color,.has-drop-cap:not(:focus):first-letter,.wp-block-button.is-style-outline,a { color: #cd2653; }blockquote,.border-color-accent,.border-color-accent-hover:hover,.border-color-accent-hover:focus { border-color: #cd2653; }button,.button,.faux-button,.wp-block-button__link,.wp-block-file .wp-block-file__button,input[type="button"],input[type="reset"],input[type="submit"],.bg-accent,.bg-accent-hover:hover,.bg-accent-hover:focus,:root .has-accent-background-color,.comment-reply-link { background-color: #cd2653; }.fill-children-accent,.fill-children-accent * { fill: #cd2653; }body,.entry-title a,:root .has-primary-color { color: #000000; }:root .has-primary-background-color { background-color: #000000; }cite,figcaption,.wp-caption-text,.post-meta,.entry-content .wp-block-archives li,.entry-content .wp-block-categories li,.entry-content .wp-block-latest-posts li,.wp-block-latest-comments__comment-date,.wp-block-latest-posts__post-date,.wp-block-embed figcaption,.wp-block-image figcaption,.wp-block-pullquote cite,.comment-metadata,.comment-respond .comment-notes,.comment-respond .logged-in-as,.pagination .dots,.entry-content hr:not(.has-background),hr.styled-separator,:root .has-secondary-color { color: #6d6d6d; }:root .has-secondary-background-color { background-color: #6d6d6d; }pre,fieldset,input,textarea,table,table *,hr { border-color: #dcd7ca; }caption,code,code,kbd,samp,.wp-block-table.is-style-stripes tbody tr:nth-child(odd),:root .has-subtle-background-background-color { background-color: #dcd7ca; }.wp-block-table.is-style-stripes { border-bottom-color: #dcd7ca; }.wp-block-latest-posts.is-grid li { border-top-color: #dcd7ca; }:root .has-subtle-background-color { color: #dcd7ca; }body:not(.overlay-header) .primary-menu > li > a,body:not(.overlay-header) .primary-menu > li > .icon,.modal-menu a,.footer-menu a, .footer-widgets a,#site-footer .wp-block-button.is-style-outline,.wp-block-pullquote:before,.singular:not(.overlay-header) .entry-header a,.archive-header a,.header-footer-group .color-accent,.header-footer-group .color-accent-hover:hover { color: #cd2653; }.social-icons a,#site-footer button:not(.toggle),#site-footer .button,#site-footer .faux-button,#site-footer .wp-block-button__link,#site-footer .wp-block-file__button,#site-footer input[type="button"],#site-footer input[type="reset"],#site-footer input[type="submit"] { background-color: #cd2653; }.header-footer-group,body:not(.overlay-header) #site-header .toggle,.menu-modal .toggle { color: #000000; }body:not(.overlay-header) .primary-menu ul { background-color: #000000; }body:not(.overlay-header) .primary-menu > li > ul:after { border-bottom-color: #000000; }body:not(.overlay-header) .primary-menu ul ul:after { border-left-color: #000000; }.site-description,body:not(.overlay-header) .toggle-inner .toggle-text,.widget .post-date,.widget .rss-date,.widget_archive li,.widget_categories li,.widget cite,.widget_pages li,.widget_meta li,.widget_nav_menu li,.powered-by-wordpress,.to-the-top,.singular .entry-header .post-meta,.singular:not(.overlay-header) .entry-header .post-meta a { color: #6d6d6d; }.header-footer-group pre,.header-footer-group fieldset,.header-footer-group input,.header-footer-group textarea,.header-footer-group table,.header-footer-group table *,.footer-nav-widgets-wrapper,#site-footer,.menu-modal nav *,.footer-widgets-outer-wrapper,.footer-top { border-color: #dcd7ca; }.header-footer-group table caption,body:not(.overlay-header) .header-inner .toggle-wrapper::before { background-color: #dcd7ca; }
</style>
<link rel='stylesheet' id='twentytwenty-print-style-css' href='https://nsdbytes.com/wp-content/themes/twentytwenty/print.css?ver=1.8' media='print' />
<link rel='stylesheet' id='elementor-icons-css' href='https://nsdbytes.com/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.12.0' media='all' />
<link rel='stylesheet' id='elementor-frontend-legacy-css' href='https://nsdbytes.com/wp-content/plugins/elementor/assets/css/frontend-legacy.min.css?ver=3.3.1' media='all' />
<link rel='stylesheet' id='elementor-frontend-css' href='https://nsdbytes.com/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=3.3.1' media='all' />
<style id='elementor-frontend-inline-css'>
@font-face{font-family:eicons;src:url(https://nsdbytes.com/wp-content/plugins/elementor/assets/lib/eicons/fonts/eicons.eot?5.10.0);src:url(https://nsdbytes.com/wp-content/plugins/elementor/assets/lib/eicons/fonts/eicons.eot?5.10.0#iefix) format("embedded-opentype"),url(https://nsdbytes.com/wp-content/plugins/elementor/assets/lib/eicons/fonts/eicons.woff2?5.10.0) format("woff2"),url(https://nsdbytes.com/wp-content/plugins/elementor/assets/lib/eicons/fonts/eicons.woff?5.10.0) format("woff"),url(https://nsdbytes.com/wp-content/plugins/elementor/assets/lib/eicons/fonts/eicons.ttf?5.10.0) format("truetype"),url(https://nsdbytes.com/wp-content/plugins/elementor/assets/lib/eicons/fonts/eicons.svg?5.10.0#eicon) format("svg");font-weight:400;font-style:normal}
</style>
<link rel='stylesheet' id='elementor-post-962-css' href='https://nsdbytes.com/wp-content/uploads/elementor/css/post-962.css?ver=1627537072' media='all' />
<link rel='stylesheet' id='elementor-pro-css' href='https://nsdbytes.com/wp-content/plugins/elementor-pro/assets/css/frontend.min.css?ver=3.0.8' media='all' />
<link rel='stylesheet' id='font-awesome-5-all-css' href='https://nsdbytes.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/all.min.css?ver=3.3.1' media='all' />
<link rel='stylesheet' id='font-awesome-4-shim-css' href='https://nsdbytes.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/v4-shims.min.css?ver=3.3.1' media='all' />
<link rel='stylesheet' id='elementor-global-css' href='https://nsdbytes.com/wp-content/uploads/elementor/css/global.css?ver=1627537072' media='all' />
<link rel='stylesheet' id='elementor-post-291-css' href='https://nsdbytes.com/wp-content/uploads/elementor/css/post-291.css?ver=1627537073' media='all' />
<link rel='stylesheet' id='elementor-post-320-css' href='https://nsdbytes.com/wp-content/uploads/elementor/css/post-320.css?ver=1627537073' media='all' />
<link rel='stylesheet' id='elementor-post-1038-css' href='https://nsdbytes.com/wp-content/uploads/elementor/css/post-1038.css?ver=1627537649' media='all' />
<link rel='stylesheet' id='google-fonts-1-css' href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CVarela+Round%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CMontserrat%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;display=auto&#038;ver=5.8.1' media='all' />
<link rel='stylesheet' id='elementor-icons-shared-0-css' href='https://nsdbytes.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min.css?ver=5.15.3' media='all' />
<link rel='stylesheet' id='elementor-icons-fa-brands-css' href='https://nsdbytes.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/brands.min.css?ver=5.15.3' media='all' />
<link rel='stylesheet' id='elementor-icons-fa-solid-css' href='https://nsdbytes.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/solid.min.css?ver=5.15.3' media='all' />
<script id='monsterinsights-frontend-script-js-extra' type="e695cee98d767db72b8d8e31-text/javascript">
var monsterinsights_frontend = {"js_events_tracking":"true","download_extensions":"doc,pdf,ppt,zip,xls,docx,pptx,xlsx","inbound_paths":"[{\"path\":\"\\\/go\\\/\",\"label\":\"affiliate\"},{\"path\":\"\\\/recommend\\\/\",\"label\":\"affiliate\"}]","home_url":"https:\/\/nsdbytes.com","hash_tracking":"false","ua":"UA-118589895-1"};
</script>
<script src='https://nsdbytes.com/wp-content/plugins/google-analytics-for-wordpress/assets/js/frontend-gtag.min.js?ver=7.18.0' id='monsterinsights-frontend-script-js' type="e695cee98d767db72b8d8e31-text/javascript"></script>
<script src='https://nsdbytes.com/wp-content/themes/twentytwenty/assets/js/index.js?ver=1.8' id='twentytwenty-js-js' async type="e695cee98d767db72b8d8e31-text/javascript"></script>
<script src='https://nsdbytes.com/wp-content/plugins/elementor/assets/lib/font-awesome/js/v4-shims.min.js?ver=3.3.1' id='font-awesome-4-shim-js' type="e695cee98d767db72b8d8e31-text/javascript"></script>
<link rel="https://api.w.org/" href="https://nsdbytes.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://nsdbytes.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://nsdbytes.com/wp-includes/wlwmanifest.xml" />
<meta name="generator" content="WordPress 5.8.1" />
<script type="e695cee98d767db72b8d8e31-text/javascript">document.documentElement.className = document.documentElement.className.replace( 'no-js', 'js' );</script>
<link rel="icon" href="https://nsdbytes.com/wp-content/uploads/2020/01/NSDBytes-icon-150x150.png" sizes="32x32" />
<link rel="icon" href="https://nsdbytes.com/wp-content/uploads/2020/01/NSDBytes-icon.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://nsdbytes.com/wp-content/uploads/2020/01/NSDBytes-icon.png" />
<meta name="msapplication-TileImage" content="https://nsdbytes.com/wp-content/uploads/2020/01/NSDBytes-icon.png" />
<style id="wp-custom-css">
			a {text-decoration: none !important;}

input[type="checkbox"] { -webkit-appearance: checkbox; }

		</style>
</head>
<body class="error404 wp-custom-logo wp-embed-responsive enable-search-modal has-no-pagination showing-comments show-avatars footer-top-hidden elementor-default elementor-template-full-width elementor-kit-962 elementor-page-1038">
<div data-elementor-type="header" data-elementor-id="291" class="elementor elementor-291 elementor-location-header" data-elementor-settings="[]">
<div class="elementor-section-wrap">
<header class="elementor-section elementor-top-section elementor-element elementor-element-2cc0375e elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="2cc0375e" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;gradient&quot;,&quot;sticky&quot;:&quot;top&quot;,&quot;sticky_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;,&quot;mobile&quot;],&quot;sticky_offset&quot;:0,&quot;sticky_effects_offset&quot;:0}">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-16 elementor-top-column elementor-element elementor-element-3676fcad" data-id="3676fcad" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-6b17014 elementor-widget elementor-widget-image" data-id="6b17014" data-element_type="widget" data-widget_type="image.default">
<div class="elementor-widget-container">
<div class="elementor-image">
<a href="https://nsdbytes.com" rel="nofollow">
<img width="536" height="306" src="https://nsdbytes.com/wp-content/uploads/2020/01/NSD-Logo-zip-1.png" class="attachment-2048x2048 size-2048x2048" alt="NSDBytes" loading="lazy" srcset="https://nsdbytes.com/wp-content/uploads/2020/01/NSD-Logo-zip-1.png 536w, https://nsdbytes.com/wp-content/uploads/2020/01/NSD-Logo-zip-1-300x171.png 300w" sizes="(max-width: 536px) 100vw, 536px" /> </a>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-66 elementor-top-column elementor-element elementor-element-32caf99" data-id="32caf99" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-21f6c7e4 elementor-nav-menu__align-right elementor-nav-menu--stretch elementor-nav-menu__text-align-center elementor-nav-menu--indicator-chevron elementor-nav-menu--dropdown-tablet elementor-nav-menu--toggle elementor-nav-menu--burger elementor-widget elementor-widget-nav-menu" data-id="21f6c7e4" data-element_type="widget" data-settings="{&quot;full_width&quot;:&quot;stretch&quot;,&quot;layout&quot;:&quot;horizontal&quot;,&quot;toggle&quot;:&quot;burger&quot;}" data-widget_type="nav-menu.default">
<div class="elementor-widget-container">
<nav role="navigation" class="elementor-nav-menu--main elementor-nav-menu__container elementor-nav-menu--layout-horizontal e--pointer-underline e--animation-drop-out"><ul id="menu-1-21f6c7e4" class="elementor-nav-menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-308"><a href="https://nsdbytes.com/" class="elementor-item">Home</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-307"><a href="https://nsdbytes.com/our-services/" class="elementor-item">Our Services</a>
<ul class="sub-menu elementor-nav-menu--dropdown">
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-306"><a href="https://nsdbytes.com/our-services/software-development/" class="elementor-sub-item">Software Development</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-305"><a href="https://nsdbytes.com/our-services/web-development/" class="elementor-sub-item">Web Development</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-304"><a href="https://nsdbytes.com/our-services/mobile-application/" class="elementor-sub-item">Mobile Application</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-364"><a href="https://nsdbytes.com/our-services/game-development/" class="elementor-sub-item">Game Development</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1207"><a href="https://nsdbytes.com/our-services/ar-development/" class="elementor-sub-item">Augmented Reality Development</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-303"><a href="https://nsdbytes.com/our-services/hire-a-professional/" class="elementor-sub-item">Hire A Professional</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-300"><a href="https://nsdbytes.com/technology/" class="elementor-item">Technology</a>
<ul class="sub-menu elementor-nav-menu--dropdown">
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-298"><a href="https://nsdbytes.com/technology/microsoft-net/" class="elementor-sub-item">Microsoft .Net</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-297"><a href="https://nsdbytes.com/technology/php-development/" class="elementor-sub-item">PHP</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1150"><a href="https://nsdbytes.com/technology/angular-js/" class="elementor-sub-item">Angular.js</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1137"><a href="https://nsdbytes.com/technology/react/" class="elementor-sub-item">React.js</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-296"><a href="https://nsdbytes.com/technology/android/" class="elementor-sub-item">Android</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-295"><a href="https://nsdbytes.com/technology/ios/" class="elementor-sub-item">iOS</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1163"><a href="https://nsdbytes.com/technology/react-native/" class="elementor-sub-item">React Native</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-705"><a href="https://nsdbytes.com/our-services/game-development/" class="elementor-sub-item">Unity3D</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-294"><a href="https://nsdbytes.com/technology/cms/" class="elementor-sub-item">CMS</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-299"><a href="https://nsdbytes.com/our-portfolio/" class="elementor-item">Our Portfolio</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-301"><a href="https://nsdbytes.com/about-us/" class="elementor-item">About Us</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-302"><a href="https://nsdbytes.com/contact-us/" class="elementor-item">Contact Us</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1121"><a href="https://nsdbytes.com/blog/" class="elementor-item">Blog</a></li>
</ul></nav>
<div class="elementor-menu-toggle" role="button" tabindex="0" aria-label="Menu Toggle" aria-expanded="false">
<i class="eicon-menu-bar" aria-hidden="true"></i>
<span class="elementor-screen-only">Menu</span>
</div>
<nav class="elementor-nav-menu--dropdown elementor-nav-menu__container" role="navigation" aria-hidden="true"><ul id="menu-2-21f6c7e4" class="elementor-nav-menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-308"><a href="https://nsdbytes.com/" class="elementor-item">Home</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-307"><a href="https://nsdbytes.com/our-services/" class="elementor-item">Our Services</a>
<ul class="sub-menu elementor-nav-menu--dropdown">
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-306"><a href="https://nsdbytes.com/our-services/software-development/" class="elementor-sub-item">Software Development</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-305"><a href="https://nsdbytes.com/our-services/web-development/" class="elementor-sub-item">Web Development</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-304"><a href="https://nsdbytes.com/our-services/mobile-application/" class="elementor-sub-item">Mobile Application</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-364"><a href="https://nsdbytes.com/our-services/game-development/" class="elementor-sub-item">Game Development</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1207"><a href="https://nsdbytes.com/our-services/ar-development/" class="elementor-sub-item">Augmented Reality Development</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-303"><a href="https://nsdbytes.com/our-services/hire-a-professional/" class="elementor-sub-item">Hire A Professional</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-300"><a href="https://nsdbytes.com/technology/" class="elementor-item">Technology</a>
<ul class="sub-menu elementor-nav-menu--dropdown">
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-298"><a href="https://nsdbytes.com/technology/microsoft-net/" class="elementor-sub-item">Microsoft .Net</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-297"><a href="https://nsdbytes.com/technology/php-development/" class="elementor-sub-item">PHP</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1150"><a href="https://nsdbytes.com/technology/angular-js/" class="elementor-sub-item">Angular.js</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1137"><a href="https://nsdbytes.com/technology/react/" class="elementor-sub-item">React.js</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-296"><a href="https://nsdbytes.com/technology/android/" class="elementor-sub-item">Android</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-295"><a href="https://nsdbytes.com/technology/ios/" class="elementor-sub-item">iOS</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1163"><a href="https://nsdbytes.com/technology/react-native/" class="elementor-sub-item">React Native</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-705"><a href="https://nsdbytes.com/our-services/game-development/" class="elementor-sub-item">Unity3D</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-294"><a href="https://nsdbytes.com/technology/cms/" class="elementor-sub-item">CMS</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-299"><a href="https://nsdbytes.com/our-portfolio/" class="elementor-item">Our Portfolio</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-301"><a href="https://nsdbytes.com/about-us/" class="elementor-item">About Us</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-302"><a href="https://nsdbytes.com/contact-us/" class="elementor-item">Contact Us</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1121"><a href="https://nsdbytes.com/blog/" class="elementor-item">Blog</a></li>
</ul></nav>
</div>
</div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-16 elementor-top-column elementor-element elementor-element-18a63d57" data-id="18a63d57" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-72e91fb3 elementor-align-center elementor-mobile-align-center elementor-hidden-phone elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="72e91fb3" data-element_type="widget" data-widget_type="icon-list.default">
<div class="elementor-widget-container">
<ul class="elementor-icon-list-items">
<li class="elementor-icon-list-item">
<a href="#elementor-action%3Aaction%3Dpopup%3Aopen%26settings%3DeyJpZCI6IjQzMCIsInRvZ2dsZSI6ZmFsc2V9"> <span class="elementor-icon-list-text">Get Estimation</span>
</a>
</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</header>
</div>
</div>
<div data-elementor-type="single" data-elementor-id="1038" class="elementor elementor-1038 elementor-location-single" data-elementor-settings="[]">
<div class="elementor-section-wrap">
<section class="elementor-section elementor-top-section elementor-element elementor-element-3311bb4c elementor-section-height-min-height elementor-section-boxed elementor-section-height-default elementor-section-items-middle" data-id="3311bb4c" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
<div class="elementor-background-overlay"></div>
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-59a4cac9" data-id="59a4cac9" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-206716d6 elementor-widget__width-auto elementor-absolute elementor-widget-mobile__width-initial elementor-invisible elementor-widget elementor-widget-image" data-id="206716d6" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;motion_fx_motion_fx_mouse&quot;:&quot;yes&quot;,&quot;motion_fx_mouseTrack_effect&quot;:&quot;yes&quot;,&quot;motion_fx_mouseTrack_direction&quot;:&quot;negative&quot;,&quot;motion_fx_mouseTrack_speed&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;0.2&quot;,&quot;sizes&quot;:[]},&quot;_animation&quot;:&quot;rotateInDownLeft&quot;,&quot;_animation_delay&quot;:&quot;400&quot;}" data-widget_type="image.default">
<div class="elementor-widget-container">
<div class="elementor-image">
<img width="155" height="140" src="https://nsdbytes.com/wp-content/uploads/2020/03/Oval.png" class="attachment-large size-large" alt="nsdbytes-animation image" loading="lazy" /> </div>
</div>
</div>
<div class="elementor-element elementor-element-3f713d5f elementor-widget__width-auto elementor-absolute elementor-widget-tablet__width-initial elementor-invisible elementor-widget elementor-widget-image" data-id="3f713d5f" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;motion_fx_motion_fx_mouse&quot;:&quot;yes&quot;,&quot;motion_fx_mouseTrack_effect&quot;:&quot;yes&quot;,&quot;motion_fx_mouseTrack_speed&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;0.1&quot;,&quot;sizes&quot;:[]},&quot;_animation&quot;:&quot;rotateInDownLeft&quot;,&quot;_animation_delay&quot;:&quot;700&quot;}" data-widget_type="image.default">
<div class="elementor-widget-container">
<div class="elementor-image">
<img width="198" height="190" src="https://nsdbytes.com/wp-content/uploads/2020/03/Fill-1.png" class="attachment-large size-large" alt="nsdbytes-animation image" loading="lazy" /> </div>
</div>
</div>
<div class="elementor-element elementor-element-5988cef2 elementor-widget__width-auto elementor-absolute elementor-widget-mobile__width-initial elementor-invisible elementor-widget elementor-widget-image" data-id="5988cef2" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;motion_fx_motion_fx_mouse&quot;:&quot;yes&quot;,&quot;motion_fx_mouseTrack_effect&quot;:&quot;yes&quot;,&quot;motion_fx_mouseTrack_speed&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;0.1&quot;,&quot;sizes&quot;:[]},&quot;_animation&quot;:&quot;rotateInUpRight&quot;,&quot;_animation_delay&quot;:&quot;500&quot;}" data-widget_type="image.default">
<div class="elementor-widget-container">
<div class="elementor-image">
<img width="99" height="99" src="https://nsdbytes.com/wp-content/uploads/2020/03/Oval-Copy.png" class="attachment-large size-large" alt="nsdbytes-animation image" loading="lazy" /> </div>
</div>
</div>
<section class="elementor-section elementor-inner-section elementor-element elementor-element-648c7fe3 elementor-section-height-min-height elementor-section-content-middle elementor-section-boxed elementor-section-height-default" data-id="648c7fe3" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
 <div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-b432f7e" data-id="b432f7e" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-19193aef elementor-widget elementor-widget-heading" data-id="19193aef" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-default">Ooops.</h2> </div>
</div>
<div class="elementor-element elementor-element-78f301d4 elementor-widget elementor-widget-heading" data-id="78f301d4" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-default"> I Think You Got Lost Between The Shapes.</h2> </div>
</div>
<div class="elementor-element elementor-element-6eeb92a2 elementor-widget elementor-widget-heading" data-id="6eeb92a2" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-default">The Page You Were Looking For Couldn't Be Found.</h2> </div>
</div>
<div class="elementor-element elementor-element-6a46a91a elementor-mobile-align-center elementor-align-center elementor-widget elementor-widget-button" data-id="6a46a91a" data-element_type="widget" data-widget_type="button.default">
<div class="elementor-widget-container">
<div class="elementor-button-wrapper">
<a href="https://nsdbytes.com" class="elementor-button-link elementor-button elementor-size-md" role="button">
<span class="elementor-button-content-wrapper">
<span class="elementor-button-icon elementor-align-icon-right">
<i aria-hidden="true" class="fas fa-arrow-right"></i> </span>
<span class="elementor-button-text">back to home page</span>
</span>
</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
<div data-elementor-type="footer" data-elementor-id="320" class="elementor elementor-320 elementor-location-footer" data-elementor-settings="[]">
<div class="elementor-section-wrap">
<section class="elementor-section elementor-top-section elementor-element elementor-element-36f955af elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="36f955af" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-745fa030" data-id="745fa030" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-3993870f elementor-widget elementor-widget-theme-site-logo elementor-widget-image" data-id="3993870f" data-element_type="widget" data-widget_type="theme-site-logo.default">
<div class="elementor-widget-container">
<div class="elementor-image">
<a href="https://nsdbytes.com">
<img width="478" height="359" src="https://nsdbytes.com/wp-content/uploads/2020/05/cropped-NSDBytes-icon.png" class="attachment-full size-full" alt="nsdbytes-logo" loading="lazy" srcset="https://nsdbytes.com/wp-content/uploads/2020/05/cropped-NSDBytes-icon.png 478w, https://nsdbytes.com/wp-content/uploads/2020/05/cropped-NSDBytes-icon-300x225.png 300w" sizes="(max-width: 478px) 100vw, 478px" /> </a>
</div>
</div>
</div>
<div class="elementor-element elementor-element-6c23fdfc elementor-widget elementor-widget-text-editor" data-id="6c23fdfc" data-element_type="widget" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<div class="elementor-text-editor elementor-clearfix">
<p>We drive with the sole purpose of helping a business achieve great level of excellence by offering out of the box solutions.</p> </div>
</div>
</div>
<div class="elementor-element elementor-element-1b496ae5 e-grid-align-left e-grid-align-mobile-center elementor-shape-rounded elementor-grid-0 elementor-widget elementor-widget-social-icons" data-id="1b496ae5" data-element_type="widget" data-widget_type="social-icons.default">
<div class="elementor-widget-container">
<div class="elementor-social-icons-wrapper elementor-grid">
<span class="elementor-grid-item">
<a class="elementor-icon elementor-social-icon elementor-social-icon-skype elementor-repeater-item-d2d5c50" href="https://join.skype.com/invite/jBUZGfFpoSi2" target="_blank">
<span class="elementor-screen-only">Skype</span>
<i class="fab fa-skype"></i> </a>
</span>
<span class="elementor-grid-item">
<a class="elementor-icon elementor-social-icon elementor-social-icon-whatsapp elementor-repeater-item-8923872" href="https://wa.me/message/77JH5TGHHSNJL1" target="_blank">
<span class="elementor-screen-only">Whatsapp</span>
<i class="fab fa-whatsapp"></i> </a>
</span>
<span class="elementor-grid-item">
<a class="elementor-icon elementor-social-icon elementor-social-icon-telegram elementor-repeater-item-d0631a3" href="https://t.me/NSDBytes" target="_blank">
<span class="elementor-screen-only">Telegram</span>
<i class="fab fa-telegram"></i> </a>
</span>
<span class="elementor-grid-item">
<a class="elementor-icon elementor-social-icon elementor-social-icon-linkedin elementor-repeater-item-44d1527" href="https://www.linkedin.com/company/nsdbytes" target="_blank">
<span class="elementor-screen-only">Linkedin</span>
<i class="fab fa-linkedin"></i> </a>
</span>
<span class="elementor-grid-item">
<a class="elementor-icon elementor-social-icon elementor-social-icon-facebook elementor-repeater-item-6afea43" href="https://www.facebook.com/nsdbytes/" target="_blank">
<span class="elementor-screen-only">Facebook</span>
<i class="fab fa-facebook"></i> </a>
</span>
<span class="elementor-grid-item">
<a class="elementor-icon elementor-social-icon elementor-social-icon-envato logo elementor-repeater-item-a96dd6c" href="https://themeforest.net/user/puffintheme" target="_blank">
<span class="elementor-screen-only">Envato Logo</span>
<svg xmlns="http://www.w3.org/2000/svg" id="Bold" height="512" viewBox="0 0 24 24" width="512"><path d="m3.968 6.694c-5.508 7.648-.534 13.909 2.723 15.896 3.813 2.326 11.334 2.325 14.329-4.275 3.732-8.219-.64-17.658-1.716-18.184l-.001.001c-.858-.422-5.211.06-8.349 3.071-4.944 4.936-4.825 11.442-4.825 11.442s-.163.669-.859-.302c-1.524-1.943-.726-6.412-.636-7.035.126-.877-.434-.903-.666-.614z"></path></svg> </a>
</span>
<span class="elementor-grid-item">
<a class="elementor-icon elementor-social-icon elementor-social-icon-dribbble elementor-repeater-item-ff4c3b4" href="https://dribbble.com/puffintheme" target="_blank">
<span class="elementor-screen-only">Dribbble</span>
<i class="fab fa-dribbble"></i> </a>
</span>
<span class="elementor-grid-item">
<a class="elementor-icon elementor-social-icon elementor-social-icon-NSDBytes - Clutch Profile elementor-repeater-item-555d55d" href="https://clutch.co/profile/nsdbytes" target="_blank">
<span class="elementor-screen-only">NSDBytes - Clutch Profile</span>
<svg xmlns="http://www.w3.org/2000/svg" id="Layer_1" data-name="Layer 1" viewBox="0 0 70.2 79.3"><defs><style>.cls-1{fill:#17313b;}.cls-2{fill:#ff3d2e;}</style></defs><title>C icon</title><path class="cls-1" d="M55.1,57A22.35,22.35,0,0,1,40,62.6c-12.8,0-22.2-9.4-22.2-22.3S26.9,18.4,40,18.4a22.9,22.9,0,0,1,15.2,5.5L58,26.3,70.4,13.9,67.3,11A40.13,40.13,0,0,0,40,.8C17,0.8.3,17.4,0.3,40.2S17.4,80.1,40,80.1A40.14,40.14,0,0,0,67.5,69.7l3-2.8L57.9,54.5Z" transform="translate(-0.3 -0.8)"></path><circle class="cls-2" cx="39.1" cy="39.6" r="13.3"></circle></svg> </a>
</span>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-26343e55" data-id="26343e55" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-2c02fa56 elementor-widget elementor-widget-heading" data-id="2c02fa56" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-default"><a href="https://nsdbytes.com/our-services/">Our Services</a></h2> </div>
</div>
<div class="elementor-element elementor-element-59930dea elementor-align-left elementor-mobile-align-left elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="59930dea" data-element_type="widget" data-widget_type="icon-list.default">
<div class="elementor-widget-container">
<ul class="elementor-icon-list-items">
<li class="elementor-icon-list-item">
<a href="https://nsdbytes.com/our-services/software-development/"> <span class="elementor-icon-list-text">Software Development</span>
</a>
</li>
<li class="elementor-icon-list-item">
<a href="https://nsdbytes.com/our-services/web-development/"> <span class="elementor-icon-list-text">Web Development</span>
</a>
</li>
<li class="elementor-icon-list-item">
<a href="https://nsdbytes.com/our-services/mobile-application/"> <span class="elementor-icon-list-text">Mobile Application</span>
</a>
</li>
<li class="elementor-icon-list-item">
<a href="https://nsdbytes.com/technology/react-native/"> <span class="elementor-icon-list-text">Cross Platform Development</span>
</a>
</li>
<li class="elementor-icon-list-item">
<a href="https://nsdbytes.com/our-services/game-development/"> <span class="elementor-icon-list-text">Game Development</span>
</a>
</li>
<li class="elementor-icon-list-item">
<a href="https://nsdbytes.com/our-services/ar-development/"> <span class="elementor-icon-list-text">AR Development</span>
</a>
</li>
<li class="elementor-icon-list-item">
<a href="https://nsdbytes.com/our-services/hire-a-professional/"> <span class="elementor-icon-list-text">Hire a Professional</span>
</a>
</li>
</ul>
</div>
</div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-796460c0" data-id="796460c0" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-6e16c3c1 elementor-widget elementor-widget-heading" data-id="6e16c3c1" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-default"><a href="https://nsdbytes.com/technology/">Technology</a></h2> </div>
</div>
<div class="elementor-element elementor-element-5b6b362c elementor-align-left elementor-mobile-align-left elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="5b6b362c" data-element_type="widget" data-widget_type="icon-list.default">
<div class="elementor-widget-container">
<ul class="elementor-icon-list-items">
<li class="elementor-icon-list-item">
<a href="https://nsdbytes.com/technology/microsoft-net/"> <span class="elementor-icon-list-text">Microsoft .Net</span>
 </a>
</li>
<li class="elementor-icon-list-item">
<a href="https://nsdbytes.com/technology/php/"> <span class="elementor-icon-list-text">PHP</span>
</a>
</li>
<li class="elementor-icon-list-item">
<a href="https://nsdbytes.com/react/"> <span class="elementor-icon-list-text">React.js</span>
</a>
</li>
<li class="elementor-icon-list-item">
<a href="https://nsdbytes.com/technology/angular-js/"> <span class="elementor-icon-list-text">Angular.js</span>
</a>
</li>
<li class="elementor-icon-list-item">
<a href="https://nsdbytes.com/our-services/game-development/"> <span class="elementor-icon-list-text">Unity3D</span>
</a>
</li>
<li class="elementor-icon-list-item">
<a href="https://nsdbytes.com/technology/android/"> <span class="elementor-icon-list-text">Android</span>
</a>
</li>
<li class="elementor-icon-list-item">
<a href="https://nsdbytes.com/technology/ios/"> <span class="elementor-icon-list-text">iOS</span>
</a>
</li>
<li class="elementor-icon-list-item">
<a href="https://nsdbytes.com/technology/react-native/"> <span class="elementor-icon-list-text">React Native</span>
</a>
</li>
<li class="elementor-icon-list-item">
<a href="https://nsdbytes.com/technology/cms/"> <span class="elementor-icon-list-text">Wordpress</span>
</a>
</li>
</ul>
</div>
</div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-6edeeef1" data-id="6edeeef1" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-69688a29 elementor-widget elementor-widget-heading" data-id="69688a29" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-default"><a href="https://nsdbytes.com/our-portfolio/">Our Portfolio</a></h2> </div>
</div>
<div class="elementor-element elementor-element-0533430 elementor-widget elementor-widget-heading" data-id="0533430" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-default"><a href="https://nsdbytes.com/about-us/">About Us</a></h2> </div>
</div>
<div class="elementor-element elementor-element-023676f elementor-widget elementor-widget-heading" data-id="023676f" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-default"><a href="https://nsdbytes.com/contact-us/">Contact Us</a></h2> </div>
</div>
<div class="elementor-element elementor-element-5cd95b1 elementor-widget elementor-widget-heading" data-id="5cd95b1" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-default"><a href="https://nsdbytes.com/blog/">Blog</a></h2> </div>
</div>
<div class="elementor-element elementor-element-8f6aab3 elementor-widget elementor-widget-heading" data-id="8f6aab3" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-default"><a href="https://nsdbytes.com/sitemap/">Sitemap</a></h2> </div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
<footer class="elementor-section elementor-top-section elementor-element elementor-element-6b7b272e elementor-section-height-min-height elementor-section-content-middle elementor-section-boxed elementor-section-height-default elementor-section-items-middle" data-id="6b7b272e" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-2cd64342" data-id="2cd64342" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-23eeb4a7 elementor-widget elementor-widget-heading" data-id="23eeb4a7" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h3 class="elementor-heading-title elementor-size-default"><a href="https://nsdbytes.com/privacy-policy-2/">© All rights reserved 2020. <b>Privacy Policy</b></a></h3> </div>
</div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-48856212" data-id="48856212" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-3cba0c48 elementor-widget elementor-widget-heading" data-id="3cba0c48" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h3 class="elementor-heading-title elementor-size-default"><a href="https://nsdbytes.com/">Made with ❤ by Team <b>NSDBytes</b></a></h3> </div>
</div>
</div>
</div>
</div>
</div>
</div>
</footer>
</div>
</div>
<div data-elementor-type="popup" data-elementor-id="430" class="elementor elementor-430 elementor-location-popup" data-elementor-settings="{&quot;entrance_animation&quot;:&quot;fadeIn&quot;,&quot;entrance_animation_duration&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:1.2,&quot;sizes&quot;:[]},&quot;timing&quot;:{&quot;page_views&quot;:&quot;yes&quot;,&quot;sessions&quot;:&quot;yes&quot;,&quot;times&quot;:&quot;yes&quot;,&quot;page_views_views&quot;:3,&quot;sessions_sessions&quot;:2,&quot;times_times&quot;:3}}">
<div class="elementor-section-wrap">
<main class="elementor-section elementor-top-section elementor-element elementor-element-2ff980a9 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="2ff980a9" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-12582427" data-id="12582427" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-20f995d8 elementor-widget elementor-widget-heading" data-id="20f995d8" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-default">Get Estimation</h2> </div>
</div>
<div class="elementor-element elementor-element-8b969d5 elementor-button-align-stretch elementor-widget elementor-widget-form" data-id="8b969d5" data-element_type="widget" data-settings="{&quot;step_next_label&quot;:&quot;Next&quot;,&quot;step_previous_label&quot;:&quot;Previous&quot;,&quot;button_width&quot;:&quot;100&quot;,&quot;step_type&quot;:&quot;number_text&quot;,&quot;step_icon_shape&quot;:&quot;circle&quot;}" data-widget_type="form.default">
<div class="elementor-widget-container">
<form class="elementor-form" method="post" name="Get Estimation">
<input type="hidden" name="post_id" value="430" />
<input type="hidden" name="form_id" value="8b969d5" />
<div class="elementor-form-fields-wrapper elementor-labels-">
<div class="elementor-field-type-text elementor-field-group elementor-column elementor-field-group-name elementor-col-100 elementor-field-required">
<label for="form-field-name" class="elementor-field-label elementor-screen-only">Name</label><input size="1" type="text" name="form_fields[name]" id="form-field-name" class="elementor-field elementor-size-sm  elementor-field-textual" placeholder="Full Name" required="required" aria-required="true"> </div>
<div class="elementor-field-type-email elementor-field-group elementor-column elementor-field-group-email elementor-col-100 elementor-field-required">
<label for="form-field-email" class="elementor-field-label elementor-screen-only">Email</label><input size="1" type="email" name="form_fields[email]" id="form-field-email" class="elementor-field elementor-size-sm  elementor-field-textual" placeholder="Email" required="required" aria-required="true"> </div>
<div class="elementor-field-type-text elementor-field-group elementor-column elementor-field-group-field_1 elementor-col-100 elementor-field-required">
<label for="form-field-field_1" class="elementor-field-label elementor-screen-only">Skype ID</label><input size="1" type="text" name="form_fields[field_1]" id="form-field-field_1" class="elementor-field elementor-size-sm  elementor-field-textual" placeholder="Skype ID" required="required" aria-required="true"> </div>
<div class="elementor-field-type-select elementor-field-group elementor-column elementor-field-group-field_fe9ba11 elementor-col-100 elementor-field-required">
<label for="form-field-field_fe9ba11" class="elementor-field-label elementor-screen-only">Your Budget</label> <div class="elementor-field elementor-select-wrapper ">
<select name="form_fields[field_fe9ba11]" id="form-field-field_fe9ba11" class="elementor-field-textual elementor-size-sm" required="required" aria-required="true">
<option value="Your Budget">Your Budget</option><option value="Less then USD 1,000">Less then USD 1,000</option><option value="USD 1,000 to USD 10,000">USD 1,000 to USD 10,000</option><option value="USD 10,000 to USD 50,000">USD 10,000 to USD 50,000</option><option value="USD 50,000+">USD 50,000+</option> </select>
</div>
</div>
<div class="elementor-field-type-textarea elementor-field-group elementor-column elementor-field-group-message elementor-col-100 elementor-field-required">
<label for="form-field-message" class="elementor-field-label elementor-screen-only">Message</label><textarea class="elementor-field-textual elementor-field  elementor-size-sm" name="form_fields[message]" id="form-field-message" rows="4" placeholder="Description" required="required" aria-required="true"></textarea> </div>
<div class="elementor-field-type-recaptcha elementor-field-group elementor-column elementor-field-group-field_3 elementor-col-100">
<div class="elementor-field" id="form-field-field_3"><div class="elementor-g-recaptcha" data-sitekey="6LctedAUAAAAAMJK21faGD_lIZ1Ncf7bVRolXCI7" data-type="v2_checkbox" data-theme="light" data-size="normal"></div></div> </div>
<div class="elementor-field-group elementor-column elementor-field-type-submit elementor-col-100 e-form__buttons">
<button type="submit" class="elementor-button elementor-size-sm">
<span>
<span class=" elementor-button-icon">
</span>
<span class="elementor-button-text">Get Quote</span>
</span>
</button>
</div>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-4efbf444" data-id="4efbf444" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-e620304 e-grid-align-right elementor-shape-rounded elementor-grid-0 elementor-widget elementor-widget-social-icons" data-id="e620304" data-element_type="widget" data-widget_type="social-icons.default">
<div class="elementor-widget-container">
<div class="elementor-social-icons-wrapper elementor-grid">
<span class="elementor-grid-item">
<a class="elementor-icon elementor-social-icon elementor-social-icon-skype elementor-repeater-item-0aacd9a" href="https://join.skype.com/invite/jBUZGfFpoSi2" target="_blank">
<span class="elementor-screen-only">Skype</span>
<i class="fab fa-skype"></i> </a>
</span>
<span class="elementor-grid-item">
<a class="elementor-icon elementor-social-icon elementor-social-icon-telegram elementor-repeater-item-0722cf9" href="https://join.skype.com/invite/jBUZGfFpoSi2" target="_blank">
<span class="elementor-screen-only">Telegram</span>
<i class="fab fa-telegram"></i> </a>
</span>
<span class="elementor-grid-item">
<a class="elementor-icon elementor-social-icon elementor-social-icon-whatsapp elementor-repeater-item-3161552" href="https://api.whatsapp.com/message/77JH5TGHHSNJL1" target="_blank">
<span class="elementor-screen-only">Whatsapp</span>
<i class="fab fa-whatsapp"></i> </a>
</span>
<span class="elementor-grid-item">
<a class="elementor-icon elementor-social-icon elementor-social-icon-facebook elementor-repeater-item-8b9ae36" href="https://www.facebook.com/nsdbytes/" target="_blank">
<span class="elementor-screen-only">Facebook</span>
<i class="fab fa-facebook"></i> </a>
</span>
</div>
</div>
</div>
<div class="elementor-element elementor-element-4791face elementor-hidden-phone elementor-invisible elementor-widget elementor-widget-image" data-id="4791face" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;slideInLeft&quot;,&quot;_animation_delay&quot;:400}" data-widget_type="image.default">
<div class="elementor-widget-container">
<div class="elementor-image">
<img width="474" height="477" src="https://nsdbytes.com/wp-content/uploads/2020/01/bicycle.png" class="attachment-large size-large" alt="" loading="lazy" srcset="https://nsdbytes.com/wp-content/uploads/2020/01/bicycle.png 474w, https://nsdbytes.com/wp-content/uploads/2020/01/bicycle-298x300.png 298w, https://nsdbytes.com/wp-content/uploads/2020/01/bicycle-150x150.png 150w" sizes="(max-width: 474px) 100vw, 474px" /> </div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</main>
</div>
</div>
<link rel='stylesheet' id='elementor-post-430-css' href='https://nsdbytes.com/wp-content/uploads/elementor/css/post-430.css?ver=1627537072' media='all' />
<link rel='stylesheet' id='e-animations-css' href='https://nsdbytes.com/wp-content/plugins/elementor/assets/lib/animations/animations.min.css?ver=3.3.1' media='all' />
<script src='https://nsdbytes.com/wp-includes/js/dist/vendor/regenerator-runtime.min.js?ver=0.13.7' id='regenerator-runtime-js' type="e695cee98d767db72b8d8e31-text/javascript"></script>
<script src='https://nsdbytes.com/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=3.15.0' id='wp-polyfill-js' type="e695cee98d767db72b8d8e31-text/javascript"></script>
<script id='contact-form-7-js-extra' type="e695cee98d767db72b8d8e31-text/javascript">
var wpcf7 = {"api":{"root":"https:\/\/nsdbytes.com\/wp-json\/","namespace":"contact-form-7\/v1"}};
</script>
<script src='https://nsdbytes.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.4.2' id='contact-form-7-js' type="e695cee98d767db72b8d8e31-text/javascript"></script>
<script src='https://nsdbytes.com/wp-includes/js/wp-embed.min.js?ver=5.8.1' id='wp-embed-js' type="e695cee98d767db72b8d8e31-text/javascript"></script>
<script src='https://nsdbytes.com/wp-includes/js/jquery/jquery.min.js?ver=3.6.0' id='jquery-core-js' type="e695cee98d767db72b8d8e31-text/javascript"></script>
<script src='https://nsdbytes.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js' type="e695cee98d767db72b8d8e31-text/javascript"></script>
<script src='https://nsdbytes.com/wp-content/plugins/elementor-pro/assets/lib/smartmenus/jquery.smartmenus.min.js?ver=1.0.1' id='smartmenus-js' type="e695cee98d767db72b8d8e31-text/javascript"></script>
<script src='https://www.google.com/recaptcha/api.js?render=explicit&#038;ver=3.0.8' id='elementor-recaptcha-api-js' type="e695cee98d767db72b8d8e31-text/javascript"></script>
<script src='https://nsdbytes.com/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.3.1' id='elementor-webpack-runtime-js' type="e695cee98d767db72b8d8e31-text/javascript"></script>
<script src='https://nsdbytes.com/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.3.1' id='elementor-frontend-modules-js' type="e695cee98d767db72b8d8e31-text/javascript"></script>
<script src='https://nsdbytes.com/wp-content/plugins/elementor-pro/assets/lib/sticky/jquery.sticky.min.js?ver=3.0.8' id='elementor-sticky-js' type="e695cee98d767db72b8d8e31-text/javascript"></script>
<script id='elementor-pro-frontend-js-before' type="e695cee98d767db72b8d8e31-text/javascript">
var ElementorProFrontendConfig = {"ajaxurl":"https:\/\/nsdbytes.com\/wp-admin\/admin-ajax.php","nonce":"a858807240","i18n":{"toc_no_headings_found":"No headings were found on this page."},"shareButtonsNetworks":{"facebook":{"title":"Facebook","has_counter":true},"twitter":{"title":"Twitter"},"google":{"title":"Google+","has_counter":true},"linkedin":{"title":"LinkedIn","has_counter":true},"pinterest":{"title":"Pinterest","has_counter":true},"reddit":{"title":"Reddit","has_counter":true},"vk":{"title":"VK","has_counter":true},"odnoklassniki":{"title":"OK","has_counter":true},"tumblr":{"title":"Tumblr"},"digg":{"title":"Digg"},"skype":{"title":"Skype"},"stumbleupon":{"title":"StumbleUpon","has_counter":true},"mix":{"title":"Mix"},"telegram":{"title":"Telegram"},"pocket":{"title":"Pocket","has_counter":true},"xing":{"title":"XING","has_counter":true},"whatsapp":{"title":"WhatsApp"},"email":{"title":"Email"},"print":{"title":"Print"}},
"facebook_sdk":{"lang":"en_US","app_id":""},"lottie":{"defaultAnimationUrl":"https:\/\/nsdbytes.com\/wp-content\/plugins\/elementor-pro\/modules\/lottie\/assets\/animations\/default.json"}};
</script>
<script src='https://nsdbytes.com/wp-content/plugins/elementor-pro/assets/js/frontend.min.js?ver=3.0.8' id='elementor-pro-frontend-js' type="e695cee98d767db72b8d8e31-text/javascript"></script>
<script src='https://nsdbytes.com/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min.js?ver=4.0.2' id='elementor-waypoints-js' type="e695cee98d767db72b8d8e31-text/javascript"></script>
<script src='https://nsdbytes.com/wp-includes/js/jquery/ui/core.min.js?ver=1.12.1' id='jquery-ui-core-js' type="e695cee98d767db72b8d8e31-text/javascript"></script>
<script src='https://nsdbytes.com/wp-content/plugins/elementor/assets/lib/swiper/swiper.min.js?ver=5.3.6' id='swiper-js' type="e695cee98d767db72b8d8e31-text/javascript"></script>
<script src='https://nsdbytes.com/wp-content/plugins/elementor/assets/lib/share-link/share-link.min.js?ver=3.3.1' id='share-link-js' type="e695cee98d767db72b8d8e31-text/javascript"></script>
<script src='https://nsdbytes.com/wp-content/plugins/elementor/assets/lib/dialog/dialog.min.js?ver=4.8.1' id='elementor-dialog-js' type="e695cee98d767db72b8d8e31-text/javascript"></script>
<script id='elementor-frontend-js-before' type="e695cee98d767db72b8d8e31-text/javascript">
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false},"i18n":{"shareOnFacebook":"Share on Facebook","shareOnTwitter":"Share on Twitter","pinIt":"Pin it","download":"Download","downloadImage":"Download image","fullscreen":"Fullscreen","zoom":"Zoom","share":"Share","playVideo":"Play Video","previous":"Previous","next":"Next","close":"Close"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"responsive":{"breakpoints":{"mobile":{"label":"Mobile","value":767,"direction":"max","is_enabled":true,"default_value":767},"mobile_extra":{"label":"Mobile Extra","value":880,"direction":"max","is_enabled":false,"default_value":880},"tablet":{"label":"Tablet","value":1024,"direction":"max","is_enabled":true,"default_value":1024},"tablet_extra":{"label":"Tablet Extra","value":1365,"direction":"max","is_enabled":false,"default_value":1365},"laptop":{"label":"Laptop","value":1620,"direction":"max","is_enabled":false,"default_value":1620},"widescreen":{"label":"Widescreen","value":2400,"direction":"min","is_enabled":false,"default_value":2400}}},
"version":"3.3.1","is_static":false,"experimentalFeatures":{"e_import_export":true,"landing-pages":true,"elements-color-picker":true,"admin-top-bar":true},"urls":{"assets":"https:\/\/nsdbytes.com\/wp-content\/plugins\/elementor\/assets\/"},"settings":{"editorPreferences":[]},"kit":{"global_image_lightbox":"yes","active_breakpoints":["viewport_mobile","viewport_tablet"],"lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":0,"title":"Page not found &#8211; NSDBytes","excerpt":""}};
</script>
<script src='https://nsdbytes.com/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.3.1' id='elementor-frontend-js' type="e695cee98d767db72b8d8e31-text/javascript"></script>
<script src='https://nsdbytes.com/wp-content/plugins/elementor/assets/js/preloaded-modules.min.js?ver=3.3.1' id='preloaded-modules-js' type="e695cee98d767db72b8d8e31-text/javascript"></script>
<script type="e695cee98d767db72b8d8e31-text/javascript">
	/(trident|msie)/i.test(navigator.userAgent)&&document.getElementById&&window.addEventListener&&window.addEventListener("hashchange",function(){var t,e=location.hash.substring(1);/^[A-z0-9_-]+$/.test(e)&&(t=document.getElementById(e))&&(/^(?:a|select|input|button|textarea)$/i.test(t.tagName)||(t.tabIndex=-1),t.focus())},!1);
	</script>
<script src="/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="e695cee98d767db72b8d8e31-|49" defer=""></script><script defer src="https://static.cloudflareinsights.com/beacon.min.js" data-cf-beacon='{"rayId":"694049b0cccb36e3","version":"2021.8.1","r":1,"token":"f79813393a9345e8a59bb86abc14d67d","si":10}'></script>
</body>
</html>
